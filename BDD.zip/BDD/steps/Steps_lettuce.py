# -*- coding: utf-8 -*-
from lettuce import step

@step(u'Given I have entered 2 into the calculator')
def given_i_have_entered_2_into_the_calculator(step):
    assert False, 'This step must be implemented'
@step(u'And I have also entered 7 into the calculator')
def and_i_have_also_entered_7_into_the_calculator(step):
    assert False, 'This step must be implemented'
@step(u'When I press add')
def when_i_press_add(step):
    assert False, 'This step must be implemented'
@step(u'Then the sum should be 9')
def then_the_sum_should_be_9(step):
    assert False, 'This step must be implemented'
@step(u'Given I have entered <number1> into the calculator')
def given_i_have_entered_number1_into_the_calculator(step):
    assert False, 'This step must be implemented'
@step(u'And I have also entered <number2> into the calculator')
def and_i_have_also_entered_number2_into_the_calculator(step):
    assert False, 'This step must be implemented'
@step(u'Then the sum should be <result>')
def then_the_sum_should_be_result(step):
    assert False, 'This step must be implemented'