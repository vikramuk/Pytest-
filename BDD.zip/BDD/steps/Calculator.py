class Calculator():
	pass
	
	def add(context):
		context.calculator = Calculator()
		calculator.add(context.number1, context.number2)
	
